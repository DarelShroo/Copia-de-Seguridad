import gzip, glob, os

contenido = 'Hay muchos contenido aquí.\n'.encode('utf-8') * 888
with gzip.open('Librerias/gzip_no_acabado/file.txt.gz', 'wb') as f:
    f.write(contenido)

with gzip.open('Librerias/gzip_no_acabado/file.txt.gz', 'rb') as f:
    file_content = f.read().decode('utf-8')
print(file_content[0:1000])

with open('Librerias/gzip_no_acabado/lorem.txt', 'r') as entrada:
    with gzip.open('Librerias/gzip_no_acabado/lorem.txt.gz', 'wb') as salida:
        datos = entrada.read().encode('utf-8')
        salida.write(datos)

for filename in glob.glob('Librerias/gzip_no_acabado/lorem*'):
    #recorreme filename contneido en glob.glob que me devuelve todos los archivos que se llamen lorem.
    size = os.path.getsize(filename)
    #size nos acumula el valor de cada archivo
    print(f'- El fichero {filename} pesa {size} bytes')

with open('Librerias/gzip_no_acabado/lorem.txt', 'rb') as f_in:
    with gzip.open('Librerias/gzip_no_acabado/lorem.txt.gz', 'wb') as f_out:
        f_out.writelines(f_in.readlines())

with gzip.open('Librerias/gzip_no_acabado/lorem.txt.gz', 'r') as f_in:
    #abrimos el archivo lorem.txt.gz en modo lectura y le llamamos f_in
    for i, line in enumerate(f_in.readlines()):
        #enumerame las lineas contenidas en f_in
        line = line.strip()
        if not line:
            continue
        print(line.decode('utf-8')[0:64])
        if i == 10:
            break