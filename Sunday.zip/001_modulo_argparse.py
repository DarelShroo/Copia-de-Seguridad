from argparse import ArgumentParser
def parseArguments():
    parser = ArgumentParser()
    parser.add_argument('--saludar',
                        '-s',
                        dest = 'salud',
                        type=str,
                        nargs = 3,
                        default='Hola persona sin nombre',
                        help='Imprime un saludo') # si se pone -- coge ese argumento como el primero
    return parser.parse_args() # Coge el parse y en base a las cosas que le configuramos elimina lo que está de por medio

args = parseArguments() # llamo a la función
#Si el argumento dentro de los argumentos (argumento -> salud)
#Es distinto que None entonces imprime Hola y donde está el %s se reemplaza el primer argumento
if args.salud != None:
    print('Hola %s' % args.salud) # Con % formateamos y donde está %s sustituimos por el contenido en ArgumentParser(), por el argumento .salud
#Desde el terminal ejecutamos python nombre_archivo.py --llamada_argumento datos a añadir aquí