import math

radio = float(input('Digite el radio del circulo: '))

area = math.pi * radio ** 2

print('El area es igual a: ', area)