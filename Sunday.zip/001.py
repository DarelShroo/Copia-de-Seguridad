import random 

class Accumulator:
    
    def __init__(self):
        print("Se llama al constructor de la clase Accumulator")
        self.value = random.randrange(1000000)
        
    def __repr__(self):
        return f"Acumulator(value={self.value})"
        
    def inc(self):
        self.value += 1
        
        
        
acc = Accumulator()
print(acc, id(acc))
acc = Accumulator()
print(acc, id(acc))