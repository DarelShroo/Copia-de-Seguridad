import re
# '^[0-9]{8}[A-Z]?$'
#'^[A-Z][0-9]{8}[A-Z]$' se pueden utilizar dos expresiones regulares
#Ejemplo #'^[A-Z][0-9]{8}|[0-9]{8}[A-Z]$'
#[^59] cualquier caracter menos 5 y 9
#| una u otra
#'^[A-Z][0-9]{8}|[0-9]{8}[A-Z]$'
#{} numero de veces que algo se repite