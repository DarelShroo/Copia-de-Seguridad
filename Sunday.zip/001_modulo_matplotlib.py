import random, statistics
import matplotlib.pyplot as plt
def dado():
    return random.randint(1,6)

def doble_dado():
    return dado() + dado()

simulacion = [doble_dado() for _ in range(10000)]
simulacion[0:5]
#ver datos de la simulacion?
statistics.mean(simulacion)

plt.hist(simulacion, bins=11, color='red')
plt.show()
'''import random
import matplotlib.pyplot as plt

markers = [
    ".", ",", "o", "v", "^", "<", 
    ">", "1", "2", "3", "4", "s",
    "p", "*", "h", "H", "+", "x", 
    "D", "d", "|", "_",
    ]
lines = ["-", "--", "-.", ":"]
colors = [ "b", "g", "r", "c", "m", "y", "k", "w" ]

line_format = random.choice(colors) + random.choice(markers) + random.choice(lines)

plt.plot([0, 1, 4, 9, 16, 25, 36], line_format)
plt.show()'''



#proyecto copia seguridad

import os
import collections

import matplotlib.pyplot as plt

EXTENSIONES = ['.pdf', '.txt', '.doc', '.mp4', '.xls', '.py', '.ipynb',
    '.csv',
    '.rst',
    '.svg',
    ]

def obtener_extension(filename):
    _, ext = os.path.splitext(filename)
    if ext in EXTENSIONES:
        return ext
    else:
        return ''
    
assert obtener_extension("arrow.ipynb") == ".ipynb"
assert obtener_extension("arrow.avi") == ""

counter = collections.defaultdict(int)
for (current_dir, list_dirs, list_filenames) in os.walk('..'):
    for filename in list_filenames:
        ext = obtener_extension(filename)
        if ext:
            counter[ext] = counter[ext] + 1

plt.barh(list(counter.keys()), counter.values())
plt.show()

#### wweeeb

r = requests.get('localhost:8000')
print(r.status_code)
print(r.headers['content-type'])
#print(r.encoding)
#print(r.text)
#print(r.json())

20:17

r = requests.get('localhost:8000')
print(r.status_code)
for nm in r.headers:
    print(nm, r.headers[nm])
    
    
print(r.headers['content-type'])

#print(r.encoding)
#print(r.text)
#print(r.json())

20:17

r = requests.get('localhost:8000')
print(r.status_code)
for nm in r.headers:
    print(nm, ':', r.headers[nm])
    
    
print(r.headers['content-type'])

#print(r.encoding)
#print(r.text)
#print(r.json())
