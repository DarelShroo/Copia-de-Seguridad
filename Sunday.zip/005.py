sexo = str(input('Escribe tu sexo M o H     '))
nombre = str(input('Escribe tu nombre  '))

if sexo.lower() == 'M':
    if nombre.lower() < 'm':
        grupo = 'A'
    else:
        grupo = 'B'
else:
    if nombre.lower() > 'n':
        grupo = 'A'
    else:
        grupo = 'B'
print('Tu grupo es ' + grupo)
