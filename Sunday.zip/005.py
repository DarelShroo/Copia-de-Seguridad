import acc
      
acc1 = acc.accumulator()
print(acc1, id(acc1))
acc2 = acc.accumulator()
print(acc2, id(acc2))
acc2.inc()
assert acc1.value == acc2.value
assert acc1 is acc2