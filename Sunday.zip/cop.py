import os , zipfile, datetime, timeit, time


day_week = datetime.datetime.today()
path, name_zip = 'Mini_Proyecto_Copia_Seguridad\\', '{:%A}.zip'.format(day_week)
full_path = '{}{}'.format(path, name_zip)
day = 0
while day<365:
    def copysecurity():
        if os.path.exists(full_path) is True:
            os.remove(full_path)
        zip_security = zipfile.ZipFile(full_path, 'w')
        for folder, subfolders, files in os.walk('C:\\Users\\XXX\\Desktop\\'):
            for file in files:
                if file.endswith(('.py', '.md', '.rst', '.csv')):
                    zip_security.write(os.path.join(folder, file), 
                    file, compress_type = zipfile.ZIP_DEFLATED)
        zip_security.close
    ini = datetime.datetime.now()
    copysecurity()
    fin = datetime.datetime.now()
    result = fin - ini
    sec = datetime.strptime(result, '%S')
    print('El programa ha tardado', sec, 'segundos')
    time.sleep(14400)
    day+=1
