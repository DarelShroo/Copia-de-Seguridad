import csv
#Carga de archivo
path = 'top50.csv'
songs = open(path, encoding='utf8')
reader = csv.reader(songs, delimiter=',')

 #He modificado top50 con una cabecera indico que es la primera línea

data = [] #Lista que me va a almacenar el contenido de songs

#Con este for añadimos linea a linea y columna a columna el contenido de songs
for row in reader:
    #row = [track_name, artist_name, genre, bpm, energy, dance, lenght ]
    track_name = str(row[0])
    artist_name = str(row[1])
    genre = str(row[2])
    bpm = int(row[3])
    energy = int(row[4])
    dance = int(row[5])
    length = int(row[6])
    data.append([track_name, artist_name, genre, bpm, energy, dance, length])

#Con este for sumamos y creamos el archivo modificado
return_path = 'top50_mod.csv'
songs = open(return_path, 'w', encoding='utf8', newline="")
writer = csv.writer(songs)
dato_int = int(input('Escriba el numero de bpm a cambiar: '))
for i in range(len(data)):
    rows_change = data[i]
    new_bpm = rows_change[3] + dato_int
    new_energy = rows_change[4] + (dato_int * 2)
    new_dance = rows_change[5] +(dato_int * 3)
    new_lenght = rows_change[6] - dato_int
    writer.writerow([rows_change[0], rows_change[1], rows_change[2], new_bpm, new_energy, new_dance, new_lenght])

