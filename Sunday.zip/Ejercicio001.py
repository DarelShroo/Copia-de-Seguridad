from samples import text
import statistics
#from statistics import stdev


#print(statistics.mean(23, 76, 99, 12))
'''
mediana = [23, 76, 99, 12] #maaal! ?????
print(statistics.mean(mediana))

mediana = [23, 76, 99, 12]
print(statistics.median(mediana))

valor_mas_frecuente = [23, 76, 99, 12, 6, 6, 8, 9, 4, 6, 2, 6, 2]
print(statistics.median(valor_mas_frecuente))
'''
def media(texto):
    texto.sort()
    if len(texto) % 2 == 0:
        n = len(texto)
        mediana = (texto [n / 2 -1] + texto[n /2]) / 2
    else:
        mediana = texto[len(texto) / 2]

    print('media: ', mediana)

    '''import os  # Usar os.path.getsize
import statistics  # User statistics.mean, statistics.stdev

sizes = []

for filename in os.listdir():
    print(filename)
    size = os.path.getsize(filename)
    # Tu codigo aqui
# Y aqui'''

set()
#dialecto
#expresiones regulares 
