class ClaseUtil:
    pass
    def main():
        util = ClaseUtil()
        print(util)
    if __name__ == "__main__":
        main()

def formato_string(strig,formatter=None):
    class DefaultFormatter:
        def format(self, string):
            return str(string).title()
    if not formatter:
        formatter = DefaultFormatter()
    return formatter.format(string)





