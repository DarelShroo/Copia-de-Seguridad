import timeit

t = timeit.Timer("print('main statement')", "print('setup')")
print('TIMEIT:')
print(t.timeit(2))
#timeit() ejecuta la declaración de configuración una vez y luego llama
#a la declaración principal count n veces. Devuelve un valor de coma flotante
#Que muestra el tiempo acumulado que a tardado en ejecutarse la instrucción
print('REPEAT:') #Con repeat llama a timeit() 3 veces.
print(t.repeat(3, 2))

print('\n')
