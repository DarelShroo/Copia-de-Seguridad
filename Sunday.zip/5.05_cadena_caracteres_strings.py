nombre = str('Edward Ortiz')
email = 'edward@mail.co' 
direccion = '''Carrera 1 #13A-29'''

print(type(nombre))
print()
print(nombre)

print()

mensaje = 'Bienvenido(a), ' + nombre + '. correo: ' + email
print(type(mensaje))
print()
print(mensaje)

print()

mensaje = f'Bienvenido(a), {nombre}. correo: {email}' 
print(mensaje)

print()

mensaje = 'Bienvenido(a), {}. correo: {}'.format(nombre, email)
print(mensaje)

print()

mensaje = 'Bienvenido(a), %s. correo: %s' % (nombre, email)
print(mensaje)

lenguaje = 'python'
print(lenguaje)
print(lenguaje[0])
print(lenguaje[1])
print(lenguaje[2])
print(lenguaje[3])
print(lenguaje[4])
print(lenguaje[5])



lenguaje = 'p' + lenguaje[1:]
print(lenguaje)

print()
print(id('python') == id('python'))

lenguaje = 'Python'.lower()
print(lenguaje)

valores = '2,3,5,7,11'
numeros = valores.split(',')
print(len(numeros))
print(numeros)
print(type(numeros[0]))

print()

indice = valores.find('2')
print(f'El indice del elemento 2 es igual a {indice}')
indice = valores.find('1')
print(f'El indice del elemento 1 es igual a {indice}')
indice = valores.find('8')
print(f'El indice del elemento 8 es igual a {indice}')

print()

# Creacion de una funcion (proceso) personalizado para buscar una cadena dentro de otra:

def encontrar(cadena, caracter):
    indice = -1
    for i in range(0, len(cadena)):
        if caracter == cadena[i]:
            indice = i
            break

    return indice

indice = encontrar(valores, '2')
print('El indice del elementos "2" es igual a', indice)