import random
class Singleton:
    _instance = None
    def __new__(class_, *args, **kwargs):
        if not isinstance(class_._instance, class_):
            class_._instance = object.__new__(class_, *args, **kwargs)        
            print("Se llama al constructor de la clase Accumulator")
            class_._instance.value = random.randrange(1000000)  
        return class_._instance

class Accumulator(Singleton):
    def __repr__(self):
        return f"Acumulator(value={self.value})" 
    def inc(self):
        self.value += 1
        
acc1 = Accumulator()
print(acc1, id(acc1))
acc2 = Accumulator()
print(acc2, id(acc2))
acc2.inc()
assert acc1.value == acc2.value
assert acc1 is acc2