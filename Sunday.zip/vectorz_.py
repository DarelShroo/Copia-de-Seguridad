import random
class PillowImp:
    
    def init(self):
        print("La implementacion de Pillow se inicializa")
        
    def point(self, x, y):
        print(f"Pillow imprime un pixel en {x}, {y}")
        
    def line(self, x0, y0, x1, y1):
        print(f"Pillow dibuja una linea entre {x0}, {y0} y {x1}, {y1}")
class PyGameImp:
    def init(self):
        print("La implementacion de PyGame se inicializa")
        
    def point(self, x, y):
        print(f"PyGame imprime un pixel en {x}, {y}")
        
    def line(self, x0, y0, x1, y1):
        print(f"PyGame dibuja una linea entre {x0}, {y0} y {x1}, {y1}")

class VectorZ:
    
    def __init__(self):
        Implementation = random.choice([PillowImp, PyGameImp])
        self.implementation = Implementation()
        self.implementation.init()
        
    def point(self, x, y):
        self.implementation.point(x, y)
        
    def line(self, x0, y0, x1, y1):
        self.implementation.line(x0, y0, x1, y1)
        
    def square(self, left, top, width, height):
        self.implementation.line(left, top, left+width, top)
        self.implementation.line(left+width, top, left+width, top+height)
        self.implementation.line(left+width, top+height, left, top+height)
        self.implementation.line(left, top+height, left, top)
    
    def punto_gordo(self, x, y):
        self.square(x-1, y-1, 2, 2)

v = VectorZ()
v.punto_gordo(15, 20)