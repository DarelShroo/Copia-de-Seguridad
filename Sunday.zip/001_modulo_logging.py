import logging
'''
#DEBUG 	Información muy detallada, normalmente de interes sólo para diagnosticar problemas y encontrar errores
#INFO 	Confirmación de que las cosas están funcionando como deben
#WARNING 	Una indicación de que ha pasado algo extraño, o en previsión de algún problema futuro (Por ejemplo, \"No queda mucho espacio libre en disco\"). El programa sigue funcionando con normalidad
#ERROR 	Debido a un problema más grave, el programa no has sido capaz de realizar una parte de su trabajo
#CRITICAL 	Un error muy grave, indica que el programa es incapaz de continuar ejecutándos'''

'''logging.warning('¡Cuidado!')
logging.info('Mira que te lo dije...')
logging.error('Esti se')
logging.critical('esti si')
print()'''

#Logging en Jupyter
'''logging.basicConfig(format='%(asctime)s %(levelname)s : %(message)s', level=logging.DEBUG, datefmt='%I:%M:%S')
logging.info('Hola')
v = 123
logging.debug('H v vale %s', v)'''

#Crear un fichero de log
print('Archivo log en ', )
logging.basicConfig(level=logging.DEBUG, 
                    format = '%(asctime)s : %(levelname)s : %(message)s',
                    filename ='Librerias/logging_no_acabado/ejemplo.log', 
                    filemode ='w'
                    )

logging.debug('Este mensaje debería ir al log') #Al configurar el nivel como DEBUG vemos que se han grabado todos los mensajes.
logging.info('Y este')
logging.warning('Y este también')
logging.error('ERROR')