text = """\
- Haga el favor de poner atención en la primera cláusula porque es muy importante. Dice que… la parte contratante de la primera parte será considerada como la parte contratante de la primera parte. ¿Qué tal, está muy bien, eh?
- No, eso no está bien. Quisiera volver a oírlo.
- Dice que… la parte contratante de la primera parte será considerada como la parte contratante de la primera parte.
- Esta vez creo que suena mejor.
- Si quiere se lo leo otra vez.
- Tan solo la primera parte.
- ¿Sobre la parte contratante de la primera parte?
- No, solo la parte de la parte contratante de la primera parte.
- Oiga, ¿por qué hemos de pelearnos por una tontería como ésta? La cortamos.
- Sí, es demasiado largo. ¿Qué es lo que nos queda ahora?
- Dice ahora… la parte contratante de la segunda parte será considerada como la parte contratante de la segunda parte.
- Eso si que no me gusta nada. Nunca segundas partes fueron buenas.
- Escuche: ¿por qué no hacemos que la primera parte de la segunda parte contratante sea la segunda parte de la primera parte?\
"""