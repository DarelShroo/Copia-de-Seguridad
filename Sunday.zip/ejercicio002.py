#A la hora de crear un archivo zipfile se utiliza open
#zip puede utilizar varios tipos de compresión zip_stored zip_deflated zip_bzip2 o zip_lzma y...
#compresslevel determina el nivel de compresio en rangos de 0 a 9
#la clase zipfile actua como gestor de contesto, puede ser utilizado con with
#archivo zip '/home/fac123/Curso/librerias/eoi/05-libs/standard/files.backup'
'''
with zipfile.ZipFile('files.backup', 'r') as ZipFile
    for filename in zf.namelist():
        print(filename)
'''

#getinfo(name) para obtener mas informacion de estos ficheros nos devuelve un objeto de tipo zipinfo con informacion del fichero
'''
import zipfile

with zipfile.ZipFile('files.backup', 'r') as zf:
    for filename in zf.namelist():
        info = zf.getinfo(filename)
        print(filename, 'pesa', info.file_size, 'bytes')
#nos faltaria poder leer el contenido de cada fichero. Es facil e intuitivo, nos proporciona un metodo open
import zipfile
with zipfile .ZipFile(''9)
'''
'''
import zipfile

with zipfile.ZipFile('files.backup', 'w') as zf:
    with zf.open('file_01.txt', 'w') as f:
        print(f.write(b'Este es el cuarto elemento')) #numeros de bytes que e he escrito en el fichero
'''


