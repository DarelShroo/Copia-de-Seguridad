import zlib
import binascii

original_data = b'Este es el texto original'
print('Original     :', len(original_data), original_data)

compressed = zlib.compress(original_data)
print('Compressed       :', len(compressed), binascii.hexlify(compressed))

decompressed = zlib.decompress(compressed)
print('Decompressed     :', len(decompressed), decompressed)
print()

original_data = b'Este es el texto original'

template = '{:>15}  {:>15}'
print(template.format('len(data)', 'len(compressed)'))
print(template.format('-' * 15, '-' * 15))
#Las funciones compress() y decompress() ambas toman un argumento de secuencia de bytes y devuelven una secuencia de bytes.
for i in range(5):
    data = original_data * i
    compressed = zlib.compress(data)
    highlight = '*' if len(data) > len(compressed) else ''
    print(template.format(len(data), len(compressed)), highlight)