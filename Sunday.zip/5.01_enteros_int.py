puntaje = 300
x = -5

print(type(puntaje))
print(type(x))

print()

print('Puntaje antes de la adición: %i' % puntaje)
puntaje = puntaje + 50 # esto es igual que puntaje += 50 
print('Puntaje antes de la adición: %i' % puntaje)
print(type(puntaje))

print()

print('valor de x antes de la adición %i' % x)
x += 10
print('valor de x despues de la adición %i' % x)
print('Tipo de dato de la variable `x`:  %s' % type(x))


print('Uso de la clase int() para crear numeros enteros:')

edad = int(input('Escriba su edad '))
print('Tipo de dato de la variable entrada: %s' % type(entrada))

total_dias = edad * 365
print('total de dias vividos hasta el momento %i ' % total_dias)
