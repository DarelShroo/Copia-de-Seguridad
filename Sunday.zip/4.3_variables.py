edad = 29
dias_vividos = 29 * 365

print('Tipo de dato de la variable edad: ', type(edad))
print('Tipo de dato de la variable dias_vividos: ', type(dias_vividos))

print()

print('Posicion de la variable edad: ', id(edad))
print('Posicion de la variable dias_vividos: ', id(dias_vividos))

print()

print('Posicion en memeria del valor 29: ', id(29))
print('Posicion en memeria del valor 10585: ', id(10585))