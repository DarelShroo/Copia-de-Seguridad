from itertools import *
from operator import itemgetter
import time
for valor in count(5,3):
    #Importante coun primer numero mas grande que el segundo XD
    print(valor, end=' ')
    if valor == 20: break
print('\n')

contador = 0
for elemento in cycle('Python'):
    #Cycle  devuelve un objeto iterable que se producirá una y otra vez, 
    #mientras no se fuerze un final
    print(elemento, end=' ')
    contador +=1 #Aquí hacemos que se sume a sí mismo
    if contador == 12: break
    #cycle('Python') Python vale 6 por tanto Python + Python = 12, se rompe el ciclo.
print('\n')

#uso de cycle en un diccionario
contador = 0
for elemento in cycle({'x':1, 'y':2, 'z':3}):
    print(elemento, end=' ')
    contador += 1
    if contador == 9: break
print('\n')

for elemento in repeat(3, 5):
    #repeat repite el 3 unas 5 veces
    print(elemento, end=' ')
print('\n')

#repeat con map
print(list(map(pow, range(20), repeat(2))))
print('\n')

#accumulate() devuelve un iterable con sumas acumuladas
for acumulado in accumulate([1, 2, 3, 4, 5]):
    print(acumulado, end=' ')
    #1 // 2 // 2+1=3 // 3 // 3+3=6 // 4 // 4+6=10 // 5 // 5+10= 15
print('\n')

#accumulate con función max
for valor_maximo in accumulate([1, 3, 4, 6, 2, 3, 1, 4, 3, 20, 5, 4], max):
    #recorre acumulate posición 0 es el uno lo imprime, posición 1 el 3 lo imprime ya que es mas grande
    #posicion 2 el 4 lo imprime porque es mas grande que el 3, posición 3 el 6 lo imprime
    #porque es mayor que 4, posición 4 el 2 lo ignora ya que 6 es mayor e imprime 6 varias veces, en las posiciones siguientes
    #hasta llegar a la posición 9 que está el 20, y para el for al no haber un numero mas grande.
    print(valor_maximo, end=' ')
print('\n')

#accumulate con lambda
for diferencia in accumulate([10,30,50], lambda a, b: b-a):
    #a = 10
    #b: b-a = b30 - a10
    print(diferencia, end=' ')
print('\n')

#chain()
for elemento in chain([1,2], [3,4,5]):
    #2*2*2*2 = 16
    #3*3*3*3 = 81
    #4*4*4*4 = 256
    print(elemento ** 4, end=' ')
print('\n')

#chain.from_iterable()  igual que chain pero solo admite un argumento iterable
for elemento in chain.from_iterable(["un","dos","tres"]):
    print(elemento, end = ' ')
print('\n')

#compress devuelve un iterable, los True o 1 dirá si la posición donde se ubica se utilizará o no
for elemento in compress('Darel', [1,0,1,0,1]):
    print(elemento, end=' ')
print('\n')

#Construye un iterable a partir del iterable de entrada sin devolver
#ningún elemento hasta que la condición del predicado sea falsa    
#dropwhile(predicate, iterable) 
for elemento in dropwhile(lambda valor: valor == 'x',
                          ['x', 'x', 'y', 'z', 'x', 'x', 'y', 'x']):
    print(elemento, end=' ')
print('\n')

#Devuelve un iterable que no cumpla la condición del predicado.
for elemento in filterfalse(lambda valor: valor == 'x',
                          ['x', 'x', 'y', 'z', 'x', 'x', 'y', 'x']):
    print(elemento, end=' ')
print('\n')

#groupby() devuelve un iterable con los elementos de entrada agrupados por su llave.
#itertools.groupby(iterable, key=None)

ciudades = [('Bolivia', 'Sucre'), ('Bolivia', 'La Paz'),
            ('Chile', 'Valdivida'), ('Chile', 'Arica'),
            ('España', 'Cádiz'), ('Perú', 'Cusco'),
            ('Perú', 'Lima')]
for clave, grupo in groupby(ciudades, lambda x: x[0]):
    print(clave, list(grupo))
print('\n')

#groupby() y itemgetter() con lista desordenada
ciudades = [("Perú", "Cusco"), ("Chile", "Valdivia"), 
            ("Bolivia", "Sucre"), ("Bolivia", "La Paz"), 
            ("España", "Cádiz"), ("Chile", "Arica"), 
            ("Perú", "Lima")]

ciudades = sorted(ciudades, key=itemgetter(0))
#con key=itemgetter(0) establecemos que el criterio de orden será el primer elemento de la lista
for clave, grupo in groupby(ciudades, itemgetter(0)):
    print(clave, list(grupo))
print('\n')

#islice() permite ternar un número de elementos partiendo 
#del inicio del iterable a un rango específico
#itertools.islice(iterable, stop) 
for elemento in islice("KLMNOPQRST", 5):
    print(elemento, end = ' ')
print('\n')

#itertools.islice(iterable, start, stop [, step])  
#Devuelve los elementos que hay desde una posición inicial a una fina
for elemento in islice("KLMNOPQRST", 5, 7):
    print(elemento, end = ' ') 
print('\n')

#itertools.takewhile(predicate, iterable) 
#En el momento que sea falso, no devuelve más elementos aunque se cumpla la condición
for elemento in takewhile(lambda x: len(x) == 1, 
                          ['a','b','ab','bc','c']):
    print(elemento, end = ' ')
print('\n')

#itertools.tee(iterable, n=2) 
a, b = tee([1,2,3,4])
for elemento1, elemento2 in zip(a, b):
    print("a:", elemento1)
    print("b:", elemento2)
print('\n')

#itertools.product(*iterables, repeat=1) 
for elemento in product("XYZ", "mn"):
    print(elemento, end = ' ')
print('\n')
for elemento in product("X", repeat = 4):
    print(elemento, end = ' ')
print('\n')
for elemento in product("XYZ", repeat = 2):
    print(elemento, end = ' ')
print('\n')

#itertools.permutations(iterable, r=None)
for elemento in permutations("123", 2):
    print(elemento, end = ' ')
print('\n')

#itertools.combinations(iterable, r) 
#devuelve un iterable basado en tuplas con las combinaciones sin repeticiones
for elemento in combinations("123", 2):
    print(elemento, end = ' ')
print('\n')

#itertools.combinations_with_replacement(iterable, r) 
#devuelve un iterable basado en tuplas con las combinaciones con repeticiones posibles
for elemento in combinations_with_replacement("123", 2):
    print(elemento, end = ' ')