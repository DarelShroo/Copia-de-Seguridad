import threading
import time
#La forma mas sencilla de usar un thread
#es crear una instancia con una función de destino y llamar a start()
#La salida serán 5  líneas con 'worker' cada una
'''def worker():
    print('worker')

threads = []
for i in range(5):
    t = threading.Thread(target=worker)
    threads.append(t)
    t.start()'''

def worker(num):
    #Es útil poder generar un hilo y pasarle argumentos para decirle que trabajo hacer.
    print('Worker: %s' % num)


threads = []
for i in range(5):
    t = threading.Thread(target=worker, args=(i,))
    #Cualquier tipo de objéto puede ser pasado como argymento al hilo.
    #Este ejemplo pasa un numero, que luego el hilo imprime.
    threads.append(t)
    t.start()

#Nombrar hilos es útil en procesos de servidor con múltiples hilos de servicio
#manejando diferentes operaciones
