class Soldier:
    
    def __init__(self):
        self.movement = 10
        self.power = 10
        
    def __str__(self):
        return "Soldier"

class Tower:
    
    def __init__(self):
        self.power = 100
        
    def __str__(self):
        return "Tower"

def enemy_factory(kind):
    Enemies = {
        'soldier': Soldier,
        'tower': Tower,
    }
    _cls = Enemies[kind]
    return _cls()


# assert enemy_factory("mecha").power == 50