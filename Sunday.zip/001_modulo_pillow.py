from PIL import Image
import os

#im = Image.open('leon.jpg')
#im.show()
#im.mode
#im.save('leon.png')
#print(im.format, im.size, im.mode)

'''from PIL import Image

with Image.open("leon.jpg") as leon:
    size = (128, 128)
    leon.thumbnail(size)
leon.show()'''

'''from PIL import Image

leon = Image.open("leon.jpg")
size = (128, 128)
leon.thumbnail(size)
#thumbnail cambia la imagen original no muestra una imagen nueva.
leon
leon.show()'''

'''from PIL import Image

leon = Image.open("leon.jpg")
box = (150, 300, 300, 450)
region = leon.crop(box)
region = region.transpose(Image.ROTATE_180)
leon.paste(region, box)'''

'''from PIL import Image

with Image.open("leon.jpg") as leon:
    leon.thumbnail((300, 400))
    red, green, blue = leon.split()
    
blue '''

'''from PIL import Image

leon = Image.open("leon.jpg")
leon.thumbnail((300, 400))
red, green, blue = leon.split()
blue 

from PIL import Image

leon = Image.open("leon.jpg")
leon.thumbnail((300, 400))
red, green, blue = leon.split()
rebuild = Image.merge("RGB", ( red, green, blue))
rebuild

from PIL import Image

with Image.open("leon.jpg") as leon:
    deformed = leon.resize((300, 150))
deformed

from PIL import Image

leon = Image.open("leon.jpg")
deformed = leon.resize((300, 150))
deformed'''

'''from PIL import Image

leon = Image.open("leon.jpg")
leon.thumbnail((400, 400))
rotated = leon.rotate(45)
rotated

from PIL import Image

leon = Image.open("leon.jpg")
leon = leon.convert("L")
leon'''

'''from PIL import Image
from PIL import ImageFilter

leon = Image.open("leon.jpg")
leon = leon.crop((0, 340, 550, 680))
leon.filter(ImageFilter.BLUR)
leon.show()'''

'''from PIL import Image
leon = Image.open("leon.jpg")
leon = leon.crop((0, 340, 550, 680))
leon = leon.point(lambda x: x * 1.6)
leon.show()'''

'''from PIL import Image

leon = Image.open("leon.jpg")
leon = leon.crop((0, 340, 550, 680))
leon = leon.point(lambda x: (x // 64) * 64)
leon.show()'''

'''from PIL import Image
from PIL import ImageEnhance

leon = Image.open("leon.jpg")
leon = leon.crop((0, 340, 550, 680))

enhancer = ImageEnhance.Brightness(leon)

leon = enhancer.enhance(2.2)
leon.show()'''

'''from PIL import Image, ImageDraw

leon = Image.open("leon.jpg")
leon.thumbnail((400, 400))
width, height = leon.size
draw = ImageDraw.Draw(leon)
draw.line((0, 0, width, height), fill="silver", width=10)
draw.line((width, 0, 0, height), fill="coral", width=10)
leon.show()'''

'''from PIL import Image, ImageDraw

leon = Image.open("leon.jpg")
leon.thumbnail((400, 400))
width, height = leon.size
draw = ImageDraw.Draw(leon)
draw.line((0, 0, width, height), fill="silver", width=12)
draw.line((width, 0, 0, height), fill="coral", width=8)
leon.show()'''

'''from PIL import Image, ImageDraw

leon = Image.open("leon.jpg")
leon.thumbnail((400, 400))
width, height = leon.size
draw = ImageDraw.Draw(leon)
for x in range(0, width, 32):
    draw.line((x, 0, x, height), fill="white", width=5)
for y in range(0, height, 32):
    draw.line((0, y, width, y), fill="white", width=5)
leon.show()'''

'''from PIL import Image, ImageDraw

leon = Image.open("leon.jpg")

width, height = leon.size
x, y = width //2, height // 2
y += 80
rect = (x-55, y-55, x+55, y+55)
draw = ImageDraw.Draw(leon)
draw.ellipse(rect, fill=(255, 0, 0), width=3)
leon.show()'''

'''leon = Image.open("leon.jpg")
print(leon.getpixel((100, 100)))'''

'''from PIL import Image

leon = Image.open("leon.jpg")
mapa = leon.load()
print(mapa[100,100])'''

'''from PIL import Image

leon = Image.open("leon.jpg")
mapa = leon.load()

x = 100
y = 100

for xx in range(-10, 11):
    for yy in range(-10, 11):
        mapa[x+xx, y+yy] = (255, 255, 255)
leon = leon.crop((0,0, 500, 300))
leon.show()'''

'''from PIL import Image

im = Image.new("L", (90, 90), 99)
im.show()K

map_mask = mask.load()

for y in range(height):
    for x in range(width):
        (r, g, b, alpha) = im.getpixel((x,y))
        if g > r + b:
            map_mask[x,y] = 0'''