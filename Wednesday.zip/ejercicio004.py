import time

time.time() - 60
print

print(time.time())
print()

print(time.asctime())
print()

print(time.localtime())
print()

print(time.gmtime())
print()

ts = time.mktime((1890, 2, 12, 15, 23, 12, 0, 0, 0)
print(time.localtime(ts).tm_wday)

weeksdays = ['Lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo']
ts = time.mktime((1890, 2, 12, 15, 23, 12, 0, 0, 0)
print(time.localtime(ts).tm_wday)
#time unix con gmtime(0) numeros de segundo
#calcular el día de una fecha indicada
datetime.timedelta() # una diferencia entre dos fecha
import datetime
hoy = datetime.date.today()
cita = hoy + datetime.timedelta(days=91)

hoy = datetime.datetime.timedelta(days=91)
muerte = 
nacimiento =

#muestra nombre de archivos me devuelve el tiempo de la ultima vez ha sido modificado modificar sus segundos y que muestre hora humana ej:10/12/1900

import os
import datetime 

for fn in os.listdir():
    print (fn, os.path.getmtime(fn))
los objetos date time son inmutables