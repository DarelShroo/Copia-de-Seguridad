base = float(input('Digite de la base del triangulo: '))
altura = float(input('Digite la altura del triangulo: '))

area = base * altura / 2
print('El area del triangulo es igual a {}'.format(area))