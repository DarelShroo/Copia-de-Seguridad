import numpy as np

'''a = np.array([1, 2, 3, 4])
print(a, type(a))

b = np.array([
    [1, 1.1, 1.2, 1.3],
    [2, 2.1, 2.2, 2.3],
    [3, 3.1, 3.2, 3.3],
])
print(b)'''




'''z = np.zeros((4,4))
z = np.zeros((4,4))

z.reshape(1,16)
print(z)'''


'''import matplotlib.pyplot as plt
import numpy as np

X = np.linspace(-9, 9, 200)

Y = np.sin(X)

plt.plot(X, Y)'''
import matplotlib.pyplot as plt
import numpy as np

X = np.linspace(-9, 9, 200)

Y = np.sin(X)*X**2

plt.plot(X, Y)

'''%%timeit

import random

n1 = (random.random() for i in range(1000000))
c1 = [x**3 for x in n1]'''