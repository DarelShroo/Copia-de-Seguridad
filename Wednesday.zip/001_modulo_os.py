import os
#El módulo os nos proporciona acceso a llamadas del SO sobre el que se ejecuta el intérprete
#Las funciones disponibles para un determinado SO están en submódulos aparte

print(os.name) #Muestra el nombre del SO donde se está ejecutando Python. Puede devolvernos posix, nt, java
print()

print(os.environ['PATH']) #Devuelve un diccionario con las variables de entornos definidas en el SO
print()
'''print(os.path.getsize('os.ipynb'))''' #Deuvuelve el tamaño en butes del fichero cuya ruta se le pasa como parámetro
'''print(os.path.getmtime('os.ipynb'))''' # Devuelve el tiempo de la ultima modificación del archivo
#El valor es en tiempo unix: numero de segundos desde el 1/1/1970
print()

print(os.listdir()) #Nos devuelve una lista con todos los nombre de las entradas en el directorio que se le pasa como parámetro
#no incluye entradas especial si no se le especifica el directorio, lista el contenido del actual
print()


for archivos in os.listdir():
    #recorre los archivos contenidos en os.listdir()
    ultima_fecha_mod_archivos = os.path.getmtime(archivos) # devuelveme el tiempo de la ultima modificacion de archivos contenidos en os.lisdir() fecha unix en segundos
    print(archivos, ultima_fecha_mod_archivos) #imprime el nombre de los archivos y el tiempo de la ultima fecha de modificación, fecha unix en segundos
print()

name, ext = os.path.splitext('001.py')
print(name) # Nombre del dichero sin extension
print(ext) #extension del fichero

#os.walk(top, topdown=True, onerror=None, followlinks=False)
'''
if __name__ == "__main__":
    for (root,dirs,files) in os.walk('/', topdown=True): con topdown True, se analizan de arriba a abajo, en False alrevez
        print(root)
        print(dirs)
        print(files)
        print('--------------------------')'''
#El root(ruta), dirs(directorios), files(archivos) contenidos en os.walk() todos estos son parámetros de os.walk
#nos devuelve tres lista cada una con el contenido de root, dirs, files


for t in os.walk('.'):
    dirpath, dirs, files = t
    print(dirpath, dirs, len(files), sep="    ") #lista las carpetas del path, y luego la ruta relativa además diciendo el numero de archivos que contiene
print('--------------------------------------------------------------------------------')
for t in os.walk('.'):
    dirthpath, _, files = t
    for filename in files:
        full_path = os.path.join(dirpath, filename) #lista el path relativo completo de cada archivo
        print(full_path)
print('--------------------------------------------------------------------------------')

acc = 0 #variable para poder hacer la suma total que ocupan en bytes los archivos
for t in os.walk('.'):
    #recorre t en os.walk
    dirpath, _, files = t
    #dirpath, _, files son parámetros de os.walk que llamamos por cada recorrido de t en os.walk
    for filename in files:
        #recorreme los archivos contenidos  archivos
        full_path = os.path.join(dirpath, filename) #muestrame el path completo relativo a donde me ubico y devueleme también el nombre completo del archivo
        size = os.path.getsize(full_path) #cada vez que se recorre t con el contenido de los parametros solicitado, muetrame el tamaño en bytes de cada archivo con su ruta.
        print(full_path, 'ocupa', size, 'bytes')
        acc = acc + size #vete acumulandome lo que ocupa en bytes cada archivo
print(f'En total, {acc} bytes') #muestrame el contenido de la suma total acumulada en bytes
