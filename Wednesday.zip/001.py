password_in = 0
def solicitar(password_in):  
    password_save = 'pass1'
    password_in = input('Introduce tu contraseña   ')
    if password_in.lower() == password_save:
        print('La contraseña está bien  ')
    else:
        print('Tu contraseña está mal')
        solicitar(password_in)
solicitar(password_in)