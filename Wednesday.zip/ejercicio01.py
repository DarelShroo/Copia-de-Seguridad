dates = ('Tokyo':38140000,'Delhi':26454000,'Shanghai':24484000,'Mumbai': 21357000,'São Paulo':21297000)
ciudad = dates.split(':')
habitantes = dates.split(',')


def diccionario(ciudad, habitantes):
    indice = -1
    for i in range(0, len(ciudad)):
        if habitantes == ciudad[i]
        indice = i
        break
return indice