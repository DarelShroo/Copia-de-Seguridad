import os

os.listdir()
for i in os.listdir():
    print(f'{i} {os.path.getmtime(i)}')
    
#!pwd para saber por que pasa

for t in os.walk(".")
    dirpath, _, files = tuple
    for filename in files:
        full_path = os.path.join(dirpath, filename)
        print(full_path)