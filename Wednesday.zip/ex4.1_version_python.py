import sys


print('Version de Python:', sys.version)

print()

print('Informacion de version: ', sys.version_info)