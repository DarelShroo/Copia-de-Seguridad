import os
import zipfile
import datetime
import time
import sys
for filename in os.listdir('Librerias/zipfile_no_acabado/'):
    #Listame los archivos contenidos el el directorio actual
    flag = zipfile.is_zipfile(filename)
    print(flag)
    #zipfile.is_zipfile(nombrearchivo) genera un booleano para saber si es un archivo zip o no.
    if flag == True:
        print(f'-{filename} "Este es un zip"')
    else:
        print(f'-{filename}')
print()

with zipfile.ZipFile('Librerias/zipfile_no_acabado/archivo.zip', 'r') as zf:
    print(zf.namelist()) # Muestra todos los archivos contenidos dentro del archivo zip.
print()

with zipfile.ZipFile('Librerias/zipfile_no_acabado/archivo.zip') as zf:
    for info in zf.infolist():
        #recorremos los archivos para mostrar la información que contienen
        #Leer metadatos de los archivos.
        print(info.filename)
        print('     Comment      :', info.comment) 
        mod_date = datetime.datetime(*info.date_time)
        print('     Modified     :', mod_date)
        if info.create_system == 0:
            system = 'Windows'
        elif info.create_system == 3:
            system = 'Unix'
        else: system = 'UNKNOWN'
        print('     System      :', system)
        print('     ZIP version :', info.create_version)
        print('     Compressed  :', info.compress_size, 'bytes')
        print('     Uncompressed:', info.file_size, 'bytes')
        print()

if __name__ == '__main__':
    print('example.zip')
print()

with zipfile.ZipFile('Librerias/zipfile_no_acabado/archivo.zip') as zf:
    for filename in ['archivo.txt', 'notthere.txt']:
        try:
            info = zf.getinfo(filename)
        except KeyError:
            print('ERROR: No se a encontrado {} en el archivo zip'.format(filename))
        else:
            #Nos dice el nombre de archivo y su tamaño en bytes
            print('{} is {} bytes'.format(info.filename, info.file_size))
print()

with zipfile.ZipFile('Librerias/zipfile_no_acabado/archivo.zip') as zf:
    for filename in ['archivo.txt', 'Other.txt']:
        try:
            data = zf.read(filename)
        except KeyError:
            print('ERROR: No se a encontrado el archivo {}'.format(filename))
        else:
            #Nos muestra el nombre de archivo y su contenido
            print(filename, ':')
            print(data)
print()

with zipfile.ZipFile('Librerias/zipfile_no_acabado/nuevo.zip', mode='w') as zf:
    #Creamos 'nuevo.zip' y almacenamos 'files.backup' dentro, sin estar comprimido
    zf.write('Librerias/zipfile_no_acabado/files.backup')
    
try:
    import zlib
    compression = zipfile.ZIP_DEFLATED
except (ImportError, AttributeError):
    compression = zipfile.ZIP_STORED

modes = {
    zipfile.ZIP_DEFLATED: 'deflated',
    zipfile.ZIP_STORED: 'stored',
}

print('Creando archivo')
with zipfile.ZipFile('Librerias/zipfile_no_acabado/write_compression.zip', mode='w') as zf:
    mode_name = modes[compression]
    print('Añadiendo files.backup en modo de compresion', mode_name)
    #Comprimiendo en modo STORED
    zf.write('Librerias/zipfile_no_acabado/files.backup', arcname='new_name.backup',compress_type=compression)
    #Con arcname modificamos el nombre original del archivo.

msg = 'Esta información no está en un archivo'
with zipfile.ZipFile('Librerias/zipfile_no_acabado/writestr.zip', mode='w', compression = zipfile.ZIP_DEFLATED) as zf:
    zf.writestr('Librerias/zipfile_no_acabado/msg_var.txt', msg) #almacenamos el contenido de la variable msg en un archivo
with zipfile.ZipFile('Librerias/zipfile_no_acabado/writestr.zip', 'r') as zf:
    #abrimos el archivo writestr.zip 
    print(zf.read('Librerias/zipfile_no_acabado/msg_var.txt')) #leemos el contenido del archivo msg_var.txt contenido en writestr.zip
print()

msg = 'Esta información no está en un archivo'
with zipfile.ZipFile('Librerias/zipfile_no_acabado/writestr_zipinfo.zip',
                     mode='w',
                     ) as zf:
    info = zipfile.ZipInfo('msg_var.txt',
                           date_time=time.localtime(time.time()),
                           )
    info.compress_type = zipfile.ZIP_DEFLATED
    info.comment = b'Remarks go here'
    info.create_system = 0
    #Una instancia ZipInfo se puede pasar a writestr() para definir la fecha de modificación y otros metadatos.
    zf.writestr(info, msg)
print()

'''with zipfile.ZipFile('Librerias/zipfile_no_acabado/append.zip', mode='w',) as zf:
    zf.write('README.TXT')

with zipfile.ZipFile('Librerias/zipfile_no_acabado/append.zip', mode='a') as zf:
    zf.write('README.TXT', arcname='README2.TXT') 
print()'''

# zipimport importar modulos desde un archivo zip