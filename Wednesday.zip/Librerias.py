import os
#cargado automáticamente) incluye funciones de ayuda para trabajar con rutas de archivos.
print(os.name)

#os.environ  diccionario que contiene variables de entorno definidas en el SO muestra...
print(environ)

#Devuelve el tamaño, en bytes, del fichero cuya ruta se la pasa como parámetro.
os.path.getsize(path)

#Devuelve una tupla de dos elementos (root, ext). En la primera posición va la ruta completa del fichero, sin extensión, y en la segunda va la extension, de forma que path == root + ext.
os.path.splitext(path)

#Devuelve el tiempo de la ultima modificación del archivo. El valor es en tiempo unix: el número de segundos desde la medianoche UTC del 1 de enero de 1970. Vease el módulo time.
os.path.getmtime(path) 

#Devuelve
os.listdir()

''' Devuelve un iterador que nos permite examinar todo un sistema de archivos. Para cada directorio y subdirectorio en la raíz (indicada por top), 
incluyendo la propia raíz, el iterador devuelte una tupla de tres elementos (normalmente llamados dirpath, dirnames y filenames); dirpath es una cadena de texto, la ruta del directorio, dirnames es una
 lista con los nombres de los subdirectorios dentro de dirpath (excluyendo los nombres especiales . y ..) y filenames es una lista de nombres de los ficheros que no son un directorio en dirpath. 
 En cualquier momento podemos tener una ruta absoluta a un archivo f en filenames haciendo os.path.join(top, dirpath, f). '''
os.walk(top, topdown=True, onerror=None, followlinks=False) 
for t in os.walk(',')
    dirpath, _, _ = t
    print(dirpath)
