horas = int(input('Numero de horas '))
coste = int(input('Coste por hora'))

print(horas*coste)