import socket

'''
s = socket.socket()


buffer = b''
with socket.socket() as s:
    s.connect(('ifconfig.io',80))
    s.send(b'GET / HTTP/1.1\r\nHost: ifconfig.io\r\nUser-Agent: curl\r\n\r\n')
    buffer = s.recv(1024)
#buffer_str = buffer.decode('utf-8')
lista = buffer.split(b'\r\n\r\n')
lista = lista[1].rstrip().decode(ascii)
print()
'''


