import math

print(math.e)
print(math.pi)
print(math.sin(math.pi))