import csv
#si el csv es un objeto debe abrirse con el parametro newline=''
csv.register_dialect('marvel', delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\') #con el delimiter, cuando haya una ',' lo entiende como columna
# con 'marvel' solo ponemos un nombre
nombre_archivo = 'Librerias/csv/top50.csv' #Creamos una variable con el path
with open(nombre_archivo, 'r') as f:
    #Con 'r' lo ponemos en modo lectura
    reader = csv.reader(f, dialect='marvel') # Esta función nos devuelve un iterador, que irá devolviendo las distintas líneas del fichero. 
    #dialect es un parámetro opcional, define un conjunto de parámetros específicos a un csv.
    for fila, columna in enumerate(reader):
        #recorreme las columnas de izquierda a derecha, con enumerate, enumera las filas
        print(columna[1], columna[-1]) # Muestrame la columna en la posición 1 y la última.
        if fila == 5:
            #Cuando lleges a la 5 fila rompe el ciclo
            break

datos = [
    ('Leonardo', 'Azul', 1452),
    ('Raphael', 'Rojo', 1483),
    ('Michelangelo', 'Naranja', 1475),
    ('Donatello', 'Violeta', 1386),
    ]
with open('ninja-turtles.csv', 'w') as a:
    
    writer = csv.writer(a)
    writer.writerows(datos)