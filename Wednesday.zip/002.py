import random

def singleton(Cls):
    instances = {}
    def getinstance(*args, **kwargs):
        if Cls not in instances:
            instances[Cls] = Cls(*args, **kwargs)
        return instances[Cls]
    return getinstance

@singleton
class Accumulator:
    def __init__(self):
        print("Se llama al constructor de la clase Accumulator")
        self.value = random.randrange(1000000)    
    def __str__(self):
        return f"Acumulator(value={self.value})"   
    def inc(self):
        self.value += 1
acc1 = Accumulator()
print(acc1, id(acc1))
acc2 = Accumulator()
print(acc2, id(acc2))
acc2.inc()
assert acc1.value == acc2.value

acc3_tricky = acc1.__class__()
print(id(acc1), id(acc3_tricky))