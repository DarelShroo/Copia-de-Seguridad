nombre = input('Digite su nombre: ')

print('Su nombre es: ', nombre)

nombre_invertido = nombre[::-1]

print('Su nombre invertido es: ', nombre_invertido)
