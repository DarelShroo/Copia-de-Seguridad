# bashrunner
* El comando almacenará contenedores de instrucciones
* Las instrucciones son comandos disponibles en sh, (alias)


* Habrá una lista de contenedores con los comandos necesarios
* Habrá un contenedor configurado

## Coontenedores
* Un contenedor es una estructura que almacena la lista de comandos ejecutadas en una sesión

## Informacion a almacenar en un contenedor
* Nombre (Identificador único)
* Lista de comandos

### Acciones extras a considerar 
* Vaciar contenedor (actual o especifico)
* vaciar lista de contenedores

## Acciones disponibles para un contenedor:
* obtener nombre del contenedor actual
* eliminar el contenedor actual
* eliminar un contenedor
* crear un contenedor
* configurar un contenedor (en base al nombre)
* correr un contenedor

## como se almacenarán los contenedores
* Para almacenar contenedores se usará un archivo oculto (unix like) (Punto por delante)

** Advertencia **:  Al tratarse de un archivo de texto plano (mas especificamente formato JSON) no debe ingresarse información sensible. 

** A VER ** :Comprobar si se puede ejecutar cosas con permiso de administrador.

## Contenedores:
* Un contenedor es una estructura que almacena la lista de comandos ejecutados en una sesión.

### Información a almacenar en un contenedor
* Nombre (Identificador único)
* Lista de comandos