import collections 
from collections import Counter
from collections import defaultdict
from collections import namedtuple

l = [1,2,3,4,1,2,3,1,2,1]

print(Counter(l)) #Me almacena el contenido de la lista 'l' en un diccionario que me devuelve
#{Numero: Veces_que_se_repite_en_la_lista} es decir me cuenta y me da un resultado

print()

p = 'palabra'
print(Counter(p)) #Cuenta cuantas veces se repite una letra.
print()

animales = 'gato perro canario perro canario perro'
print('animales.split',animales.split()) #Me devuelve una lista con cada dato de la lista, separado por comas
print()
print(Counter(animales).most_common(10)) #Me muestra las 10 letras que más se repiten y el numero de veces almacenadas en un diccionario
print()

print('Counter(animales.split())',Counter(animales.split())) # Me cuenta cuantas veces se repite un dato de la lista
print()

l = [10,20,30,40,10,20,30,10,20,10]
c = Counter(l) # Transformamos la lista en un contador
print(c.items()) #muesta las clases y el número de veces que se repite.
print()

print(c.keys()) #Me devuelve solo las llaves del diccionario.
print()

print(c.values()) # Nos devuelve el numero de repeticiones(Valor)
print(sum(c.values())) # Nos devuelve la suma de c.values

d = {} #Importamos el modulo defaultdict
d = defaultdict(float)
print(d['algo'], 'float') #Tipo float por defecto en diccionario
print()

d = defaultdict(str)
print(d['algo'], 'str') #Tipo str por defecto en diccionario
print()

d = defaultdict(int) #Tipo int por defecto en diccionario
d['algo'] = 10.5
print(d['algo'], 'int')

n = {}
n['uno'] = 'one'
n['dos'] = 'two'
n['tres'] = 'three'
print(n)
print()

n = collections.OrderedDict()
n['uno'] = 'one'
n['dos'] = 'two'
n['tres'] = 'three'
print(n)
print()

#tuplas con nombres
persona = namedtuple('persona', 'nombre apellido edad') #importamos namedtuple

p = persona(nombre='Charlie',apellido='Sanchez',edad=25)
print(p[0]) 
print(p[1])
print(p[-1])

