import arrow, time, datetime
now = arrow.get()
ts = arrow.get('2020-06-11T21:23:58.970460+07:00')
d1 = arrow.get(2020, 3, 3)
d2 = arrow.get('2020-03-03')

assert d1 == d2
#assert asegurate de que es verdad
now = arrow.now('Asia/Istanbul')
#diferencia entre dos zonas horarias
print(now.utcoffset())

now = arrow.now('Asia/Istanbul')
print(now) #formato iso

now = arrow.now('Europe/Madrid')
now2 = arrow.now('Europe/Berlín')
now3 = arrow.now('Asia/Istanbul')

print(arrow.get(1487900664))
print(arrow.get(1367900664.152325))
print(arrow.get(time.time()))

print(arrow.get(datetime.date.today()))
print(arrow.get(datetime.datetime.now()))
print(arrow.get(datetime.datetime.now(), "Europe/Paris"))


import arrow

arrow.get('2022-04-19 12:30:45', 'YYYY-MM-DD HH')

d = arrow.get(
    'Diana, princesa de Gales, nacida el 1 de julio de 1961 en Norfolk, Inglaterra',
    'D [de ]MMMM [de ]YYYY',
    locale="ES_es",
)
print(d)
'''
pip install matplotlib
import matplotlib.pyplot as plt

simulation = [random.gauss(10, 0.0245) for _ in range(10000)]

plt.hist(simulation, bins=25)
plt.show()'''

import matplotlib.pyplot as plt
x_values = [0,1,2,3,4,5]  # Datos eje X

squares = [0,1,4,9,16,25]  # Datos eje Y

plt.plot(x_values, squares)  # plot usa un grafico de lineas 

plt.show()  # Mostrar la imagen