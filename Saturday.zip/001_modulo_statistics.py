import statistics
import os
from samples import text
import re
print(statistics.mean([23,20,19,20,3])) #calcula la media aritmetica 
print(statistics.geometric_mean([20,20,3])) #Con geometricmean calculas la media geométrica
print(statistics.median([23, 76, 99, 120])) #Con median calcula la mediana de una serie de valores
print(statistics.mode([1, 2, 4, 4, 4, 4, 7, 39142])) # Nos devuelve la moda, el valor que más se repite
print(statistics.mode(["red", "blue", "blue", "blue", "blue", "blue", "blue", "red", "green", "red", "red"])) #acepta valores discretos también
def text_to_words(text):
    pat_seps = re.compile("[-\s!?¿+.,;:]+")
    words = (w.strip().lower() for w in pat_seps.split(text))
    return [w for w in words if w]

text = """\
- Haga el favor de poner atención en la primera cláusula porque es muy importante. Dice que… la parte contratante de la primera parte será considerada como la parte contratante de la primera parte. ¿Qué tal, está muy bien, eh?
- No, eso no está bien. Quisiera volver a oírlo.
- Dice que… la parte contratante de la primera parte será considerada como la parte contratante de la primera parte.
- Esta vez creo que suena mejor.
- Si quiere se lo leo otra vez.
- Tan solo la primera parte.
- ¿Sobre la parte contratante de la primera parte?
- No, solo la parte de la parte contratante de la primera parte.
- Oiga, ¿por qué hemos de pelearnos por una tontería como ésta? La cortamos.
- Sí, es demasiado largo. ¿Qué es lo que nos queda ahora?
- Dice ahora… la parte contratante de la segunda parte será considerada como la parte contratante de la segunda parte.
- Eso si que no me gusta nada. Nunca segundas partes fueron buenas.
- Escuche: ¿por qué no hacemos que la primera parte de la segunda parte contratante sea la segunda parte de la primera parte?
"""

words = text_to_words(text)

words = text_to_words(text)
words[0:10]

sizes = []

for filename in os.listdir():
    # print(filename)
    size = os.path.getsize(filename)
    sizes.append(size)
print(f"Tam. medio: {statistics.mean(sizes)}")
print(f"Desviacion estandar: {statistics.stdev(sizes)}")
print(f"Max. tam.: {max(sizes)}")
print(f"Min. tam.: {min(sizes)}")