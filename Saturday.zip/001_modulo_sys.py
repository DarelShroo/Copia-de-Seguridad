import sys

#con python3 archivo_python.py se ejecuta el programa siempre y cuando __name_ sea __main__
if __name__ == '__main__':
    if len (sys.argv) == 1:
        #Con sys.argv coloca al script en una posición inicial en la que se necesita pasarle parametros
        print('Es necesario colocar almenos un argumento')
    else:
        if sys.argv[1] == 'help':
            print('Puedes contactar')
        print(sys.argv[1]) #Solicita un argumento partiendo desde la posicion 1 hacia la derecha
print('---------------------------------------------------------------------------------')


print('Versión',sys.version) #Nos muestra la versión de python utilizada
print('---------------------------------------------------------------------------------')

print('Path:')
for path in sys.path:
    print(f' - {path}')

print('---------------------------------------------------------------------------------')

print('sys.version_info', sys.version_info) #Nos muestra informacion de la versión del interprete
print('---------------------------------------------------------------------------------')

print('sys.version_info.major',sys.version_info.major)
print('---------------------------------------------------------------------------------')

print('sys.version_info.minor',sys.version_info.minor)
print('---------------------------------------------------------------------------------')

print('sys.path',sys.path) #Nos muestra una cadena de texto con las rutas de los modulos y paquetes python
print('---------------------------------------------------------------------------------')

print('Plataforma: ',sys.platform) #Nos dice la versión de python en ejecución
print('---------------------------------------------------------------------------------')

def funcion():
    try:
        print('Ejemplo')
    except:
        print(sys.exc_info) #tipo, valor = sys.exc_info()[:2]
        #sys.exc_info nos muestra traza, tipo y valor de la excepción
'''---------------------------------------------------------------------------
ZeroDivisionError                         Traceback (most recent call last)
<ipython-input-2-a9d1013f106c> in <module>
      5     g()
      6 
----> 7 f()

<ipython-input-2-a9d1013f106c> in f()
      3 
      4 def f():
----> 5     g()
      6 
      7 f()

<ipython-input-2-a9d1013f106c> in g()
      1 def g():
----> 2     1/0
      3 
      4 def f():
      5     g()

ZeroDivisionError: division by zero'''
print('---------------------------------------------------------------------------------')


