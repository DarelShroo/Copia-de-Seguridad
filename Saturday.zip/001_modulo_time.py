import time
'''Definicione
    UTC es el tiempo coordinado Universal, anteriormente conocido como GMT o Hora de Greenwich
    (El acrónimo UTC es un compromiso entre el inglés y el francés)

    DST es el ajuste de horario de verano (Daylight Saving Time) una modificacion de la zona horaria,
    normalmente de una hora, que se realiza durante parte del año. las reglas de los DST son, en la práctica,
    pura magia (dependen de las leyes locales) y pueden cambiar de año a año,'''

print('time.time()',time.time(),'\n') #Devuelve el tiempo en segundos, en forma de número de coma flotante.
print('time.asctime()',time.asctime(),'\n')
print('time.gmtime()',time.gmtime(), '\n') #Convierte un tiempo en segundos en una tupla de nueve elementos, en los cuales el flag final es siempre 0. Si no se indica el tiempo , se tomará el momento actual.
print('time.gmtime([secs])',time.gmtime(500000000), '\n')
print('time.localtime([secs]', time.localtime(10000))

'''Los valores de tiempo devueltos por gmtime(), localtime() y strptime(),
y aceptados por asctime(), mktime() y strftime() son tuplas (En realidad, namedtuple)
de 9 enteros: año, mes, dia, horas, minutos, segundos, día de la semana, día dentro
del año y un indicador de si se aplica o no el horario de verano.'''
print('-------------------------------------------------------------------------------')

year, mes, dia, hh, mm, ss, wday, yday, dst = time.gmtime()
print('hh, mm, ss',hh, mm, ss)
print(wday, yday, dst)
print('-------------------------------------------------------------------------------')
dt = time.gmtime()
print('dt',dt, '\n')
print('dt.tm_year',dt.tm_year, '\n')

time.sleep(5) # suspende la ejecución del programa en tiempo en segundos indicado