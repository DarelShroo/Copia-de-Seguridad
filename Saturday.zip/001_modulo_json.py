import json
import arrow

#user_json = '''{"username": "fmiller", "dob": "1988-02-26", "active": true}'''
#user = json.loads(user_json)

#print(user)
print()

#señalizar el objeto
#d = {'name':'Bob', 'age':44, 'isEmployed':True}
#s = json.dumps(d) 
#print(s, type(s))

'''class SuperJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, arrow.Arrow):
            return obj.for_json()
        return super().default(obj)

def as_json(obj):
    return json.dumps(obj, cls=SuperJSONEncoder, indent=4)'''
class Card:

    SUITS = {'T': 'trébol', 'D': 'diamantes', 'C': 'corazones', 'P': 'picas'}

    VALUES = {
        'A': 'as',
        '2': 'dos',
        '3': 'tres',
        '4': 'cuatro',
        '5': 'cinco',
        '6': 'seis',
        '7': 'siete',
        '8': 'ocho',
        '9': 'nueve',
        '10': 'diez',
        'J': 'jota',
        'Q': 'reina',
        'K': 'rey',
    }

    def __init__(self, code):
        self.suit = code[0]
        self.value = code[1:]

    def suit_name(self):
        return self.SUITS[self.suit]

    def value_name(self):
        return self.VALUES[self.value]

    def __str__(self):
        return f"{self.value_name()} de {self.suit_name()}"
    
    def to_dict(self):
        return {
            'suit' : self.suit,
            'value': self.value
        }

carta = Card('D2')
print(carta.to_dict())
'D2'

'''https:api.tfl.gov.uk/Line/bakerloo%2Cvictoria%2Ccentral%2Cjubilee%2Cdlr'''

'''url = "api.tfl.gov.uk/Line/bakerloo,victoria,central,jubilee,dlr"
r = requests.get(url)
assert r.status_code == 200
for line in r.json():
    name = line['name']
    mode_name = line["modeName"]
    disruptions = line["disruptions"]
    print(f"{name} [{mode_name}] {len(disruptions)} disruptions")'''
    