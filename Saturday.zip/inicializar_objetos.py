import math
class Punto:
    def calcular_distancia(self, otro_punto):
        return math.sqrt(
            (self.x - otro_punto.x)**2 +
            (self.y - otro_punto.y)**2)
    def __init__(self, x=0, y=0): 
        self.mover(x, y)
    def mover(self, x, y):
        self.x = x
        self.y = y
    def reiniciar(self):
        self.mover(0,0)
punto = Punto(4, 2)
print(punto.x, punto.y)