llueve = False
print(type(llueve))
print(llueve)

llueve = not llueve
print(type(llueve))
print(llueve)
if llueve:
    print('El día está lluvioso.')
else:
    print('El día está esplendido. ')

print()

#Operaciones con valores booleanos o lógicos
llave1 = True
llave2 = False

#Operadores lógicos: and (conjunción - y), or (disyunción - o)
print(llave1 and llave2)
print(llave1 and not llave2)
print(llave2 or llave1)
print(llave2 or not llave1)

print()

if llave1 and llave2:
    print('Si hay agua')
else:
    print('No hay agua')

print()

if llave1 and not llave2:
    print('Si hay agua')
else:
    print('No hay agua')

print()

if llave1 or llave2:
    print('Si hay agua')
else:
    print('No hay agua')

print()

if not llave1 or llave2:
    print('Si hay agua')
else:
    print('No hay agua')

print()

print('uso de la clase bool()')
x = bool(1)
print(type(x))
print(x)

print()

x = bool(123)
print(type(x))
print(x)

print()

x = bool(-123)
print(type(x))
print(x)

print()

x = bool(0)
print(type(x))
print(x)

print()

x = bool('False')
print(type(x))
print(x)

print()

x = bool('True')
print(type(x))
print(x)

print()

x = bool(123 < 124)
print(type(x))
print(x)

print()

x = 123 > 124
print(type(x))
print(x)