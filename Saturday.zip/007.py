class Soldier:
    
    def __init__(self):
        self.movement = 10
        self.power = 10
        
    def __str__(self):
        return "Soldier"

class Tower:
    
    def __init__(self):
        self.power = 100
        
    def __str__(self):
        return "Tower"

def make_enemy(kind):
    Enemies = {
        'soldier': Soldier,
        'tower': Tower,
    }
    _cls = Enemies[kind]
    return _cls()

s1 = make_enemy('soldier')
t1 = make_enemy('tower')
print(s1, t1)