import copy
a = list(range(5))
print(a)
b = a
print(b, '\n', b is a)
print()

#en ocasiones querremos tener dos objetos iguales
#aunque independientes el uno del otro
a = list(range(5))
print(a)
b = copy.copy(a) #Copy actua sobre cualquier objeto mutable
print(b, '\n', b is a)
print()

a = [[1,2,3], [5,8,9,2,2]]
b = copy.copy(a)
b[1].append(5)
print(a, '\n', a[1] is b[1]) #a y b son distintos pero sus referencias internas hacen referencia a los mismos objetos
print()

a = [[1,2,3], [5,8,9,2,2]]
b = copy.deepcopy(a)
b[1].append(5)
print(a, '\n', a[1] is b[1]) #Para que sus referencias internas también sean otros objetos sea utiliza deepcopy.

class Student:
    def __init__(self, subjects):
        self.subjects = subjects

student1 = Student(['Matemática', 'Geografía'])
#Si tenemos otro estudiante que comparte las mismas materias y queremos añadir una nueva 
#Se hace lo siguiente
student2 = copy.deepcopy(student1)
student2.subjects.append('Literatura')
print(student1.subjects, '\n', student2.subjects)
print('¿Es student1 el mismo objeto que student 2? ->', student1 is student2)
###
'''Tanto copy.copy() como copy.deepcopy() lanzan la excepción copy.error en 
caso que ocurra un error interno, y TypeError cuando se pasa como argumento un objeto que no 
puede ser copiado (por ejemplo, un socket).'''
###