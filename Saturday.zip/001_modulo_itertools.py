from itertools import *

for i in chain([1,2,3], ['a','b','c']):
    #chain() toma varios iteradores como argumentos y devuelve todas las entradas como un solo iterador
    print(i, end=' ')

print()

def make_iterables_to_chain():
    yield [1,2,3]
    yield ['a', 'b', 'c']
#Si los elementos que se van a combinar no son conocidos por adelantado o no son necesario para ser evaluado,
#se puede usar chain.from_iterable() para construir la cadena

for i in chain.from_iterable(make_iterables_to_chain()):
    print(i, end=' ')

print() 

for i in zip([1,2,3], ['a','b','c']):
    #Si se agota el primer iterador, se para.
    #con el iterador zip() obtenemos uno a uno los elementos de los argumentos iterables.
    print(i)

print()

r1 = range(3)
r2 = range(2)

print('Aquí termina temprano el zip(): ')
print(list(zip(r1, r2)))

r1 = range(3)
r2 = range(2)

print('\nAquí usamos zip_longest: ')
# zip_longest nos devuelve None, si no hay ningun valor
print(list(zip_longest(r1, r2, fillvalue='No hay valor')))
print('\n')


