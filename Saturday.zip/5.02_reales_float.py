pi = 3.1415
precio = 29.95

print('el valor de la variable pi es %f' %pi )
print('el valor de la variable precio es %f' % precio)
print(pi)
print(precio)

print()

print('el tipo de dato para la variable pi', type(pi))
print('el tipo de dato para la variable precio', type(precio))

print()

print('operaciones aritmeticas sobre numeros de punto flotante')
pi = pi * 2
print('el nuevo valor de la variable pi es: ', pi)

total = precio * 5
print('el tototal de la compra es: %.2f' % total)

print()

print('el tipo de dato para la variable pi:', type(pi))
print('el tipo de dato para la variable total:', type(total))

print()

print('Creacion de un numero real (punto flotante) a partir de una cadena de caracteres: ')

precio_computador = float(input('Digite el precio del ordenador: '))
print('El tipo de datos de la variable precio_computador es: %s' % type(precio_computador))
print('el computador cuesta: $%.2f' % precio_computador)