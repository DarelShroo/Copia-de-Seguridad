import re
cadena ='Vamos a aprender expresiones regulares de Python. Python es un lenguaje de de sintaxis sencilla'

#print(re.search('aprender', cadena))

textoBuscar = ' Python'
'''
if re.search(textoBuscar, cadena) is not None: 
    # re.search(QUE_VOY_A_BUSCAR, DONDE_BUSCAR), SI DEVUELVE None no se ha encontrado
    print('He encontrado el texto') # Si se cumple la condición muestrame este mensaje
else:
    print('No he encontrado el texto')'''

texto_encontrado = re.search(textoBuscar, cadena)

print(texto_encontrado.start) #Nos muestra la posición donde comienza
print(texto_encontrado.end) # Nos muestra la posición donde acaba
print(texto_encontrado.span) #Nos devuelve una tupla con la posición donde inicia y donde acaba el carácter encontrado

print(re.findall(textoBuscar, cadena)) #Nos devuelve una lista con los valores encontrados repetidos todas las veces que lo ha encontrado

lista_nombre = ['Ana Gómez',
                'María Martín',
                'Sandra López',
                'Santiago Martín',
                'niños',
                'niñas',
                'camión',
                'camion']

for nombre in lista_nombre:
    if re.findall('^San', nombre):
        # con '^' le decimos los elementos que comienzen por San
        print(nombre)
print()

for nombre in lista_nombre:
    if re.findall('ez$', nombre):
        # con '$' le decimos los elementos que terminen en 'ez'
        print(nombre)
print()

for nombre in lista_nombre:
    if re.findall('[M]', nombre):
        # con '[M]]' nos muestra todas las partes donde se ubica el carácter M
        print(nombre)
print()

for nombre in lista_nombre:
    if re.findall('niñ[ao]', nombre):
        # con 'niñ[ao]' nos muestra el patrón fijo 'niñ[]s' me da igual una cosa u otra que esté entre corchetes
        print(nombre)

print()

for nombre in lista_nombre:
    if re.findall('cami[óo]n', nombre):
        # con 'cami[óo]n' nos muestra camión y camion, con y sin tilde
        print(nombre)

print()

nombre_personas = ['Ana',
                   'Pedro',
                   'María',
                   'Rosa',
                   'Sandra',
                   'Celia']

for nombres in nombre_personas:
    if re.findall('[o-t]', nombres):
        #Buscame todos los nombres que tengan una letra comprendida en el rango de o a t. [o p q r s t]
        #Distingue entre mayusculas y minusculas
        print(nombres)

print()

for nombres in nombre_personas:
    if re.findall('^[O-T]', nombres):
        #Buscame todos los nombres que comienzen con una letra comprendida en el rango de O a T. [O P Q R S T]
        #Distingue entre mayusculas y minusculas
        print(nombres)

print()

for nombres in nombre_personas:
    if re.findall('[o-t]$', nombres):
        #Buscame todos los nombres que terminen con una letra comprendida en el rango de o a t. [o p q r s t]
        #Distingue entre mayusculas y minusculas
        print(nombres)

print()

comunidades = ['Ma.1',
                'Sv1',
                'Ma2',
                'Ba1',
                'Ma3',
                'Va1',
                'Va2',
                'Ma4',
                'MaA',
                'Ma5',
                'MaB',
                'Ma:C']


for nombres in comunidades:
    if re.findall('Ma[0-3]', nombres):
        print(nombres)

print()

for nombres in comunidades:
    if re.findall('Ma[^0-3]', nombres):
        #Con '^' le decimos buscame el patron 'Ma[todo menos el rango 0 a 3]. NEGAMOS
        print(nombres)

print()

for nombres in comunidades:
    if re.findall('Ma[0-3A-B]', nombres):
        #Buscame el patron 'Ma[En el rango 0 a 3 y además en el rango A - B]
        print(nombres)

for nombres in comunidades:
    if re.findall('Ma[.:]', nombres):
        #Buscame el patron 'Ma[. o :]. NEGAMOS
        print(nombres)

print()

nombre1 ='Sandra López'
nombre2 = 'Antonio Gómez'
nombre3 = 'sandra López'
nombre4 ='Jara López'
nombre5 ='Lara López'
cadena1 ='Jara López'
cadena2 ='5649674964'
cadena3 ='a546546'
codigo1 ='fkljdshfohsofaiojdohjadoahdsupahdf71p9uywqae'
codigo2 ='ahjsd71ahsdw0dohjadajwjà'
codigo3 ='5456664644iuashuisghd a dsuias dasdhoas  ahdsoapydso '
if re.match('Sandra', nombre2):
    #con el atributo match buscamos un patrón al comienzo de una cadena, solo al comienzo
    print('Hemos encontrado el nombre')
else:
    print('No lo hemos encontrado')

print()

if re.match('Sandra', nombre3):
    #Distingue entre mayusculas y minusculas
    print('Hemos encontrado el nombre')
else:
    print('No lo hemos encontrado')

print()

if re.match('Sandra', nombre3, re.IGNORECASE):
    #Con el tercer parámetro si es sensitive-case que lo ignore
    print('Hemos encontrado el nombre')
else:
    print('No lo hemos encontrado')


if re.match('.ara', nombre4, re.IGNORECASE):
    #Comodín '.' sustituye un único carácter. El punto dice cualquíer caracter seguido del patrón
    print('Hemos encontrado el nombre')
else:
    print('No lo hemos encontrado')

print()

if re.match('\d', cadena2):
    #le decimos lo que comienze por un número
    print('Hemos encontrado el numero')
else:
    print('No lo hemos encontrado')

print()

if re.search('López', nombre3):
    #con search busca en toda la cadena un patrón de búsqueda en concreto
    print('Hemos encontrado el numero')
else:
    print('No lo hemos encontrado')

print()

if re.search('71', codigo2):
    #con search busca en toda la cadena un patrón de búsqueda en concreto
    print('Hemos encontrado el numero')
else:
    print('No lo hemos encontrado')
