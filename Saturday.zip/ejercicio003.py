import os
import zipfile

#crear aqui el fichero ZIP,  abriendolo para escritura
fantasy_zip = zipfile.ZipFile('archive.zip', 'w')
for fn in os.listdir():
    base_name, ext = os.path.splitext(fn)
    print(f"{base_naame} es un fichero de tipo {ext}")
    #Decidir si almaceno el fichero en el zip o no
    #si es que si: guardar el archivo

'''
import os
import zipfile
 
fantasy_zip = zipfile.ZipFile('C:\\Stories\\Fantasy\\archive.zip', 'w')
 
for folder, subfolders, files in os.walk('C:\\Stories\\Fantasy'):
 
    for file in files:
        if file.endswith('.pdf'):
            fantasy_zip.write(os.path.join(folder, file), os.path.relpath(os.path.join(folder,file), 'C:\\Stories\\Fantasy'), compress_type = zipfile.ZIP_DEFLATED)
 
fantasy_zip.close()
'''
'''
mport zipfile
import os

# Crear aqui el fichero ZIP, abriendolo para escritura

for fn in os.listdir():
    base_name, ext = os.path.splitext(fn)
    print(f"{base_name} es un fichero de tipo {ext}")
    # Decidir si almaceno el fichero en el ZIP o no
    # Si es que si:
    #     Guardar el archivo
    
# Cerrar el archivo con .close (a no ser que usaras with)
'''
