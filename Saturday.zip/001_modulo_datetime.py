import datetime, time
#hour, minute, second y microsecond, además de zona horaria

tiempo = datetime.time(1,2,3)
print(tiempo) #Nos muestra la hora completa en formato hh/mm/ss
print()
print('hora :', tiempo.hour) # hora actual
print('hora :', tiempo.minute) # minutos actuales
print('hora :', tiempo.second) # segundos actuales
print('hora :', tiempo.microsecond) #microsegundos actuales
print('hora :', tiempo.tzinfo) #zona horaria actual

print('Earliest :', datetime.time.min) #Mas temprano
print('Latest :', datetime.time.max) #Mas tarde
print('Resolution :', datetime.time.resolution) #resolución, limitada a microsegundo completos
print()

#la coma flotante para microsegundo provocan TypeError

hoy = datetime.date.today() #Nos muestra la fecha actual
print(hoy)
print('ctime: ', hoy.ctime()) #Nos muestra la fecha actuales con día y hora
tt = hoy.timetuple()# Transformamos la fecha en una tupla para poder sacar valores
print('tuple : tm_year', tt.tm_year)
print('        tm_mon', tt.tm_mon) #días que faltan para acabar la semana?
print('        tm_mday', tt.tm_mday)
print('        tm_hour', tt.tm_hour)
print('        tm_min', tt.tm_min)
print('        tm_sec', tt.tm_sec)
print('        tm_wday', tt.tm_wday)
print('        tm_yday', tt.tm_yday)
print('        tm_isdst', tt.tm_isdst)
print('Ordinal', hoy.toordinal()) #Nos muesta los días pasados desde el año 0
print('Hora', hoy.year)
print('Mes', hoy.month)
print('Día', hoy.day)
print()

d1 = datetime.date(2000, 1, 1)
print('d1:', d1.ctime())
d2 = d1.replace(year=2002) #Modificamos solo el año
print('d2:', d2.ctime())
#restar fechas produce timedelta que se puede agregar o restar a una fecha para generar otra.
#los timedelta almacenan día, segundos y microsegundos
#un time delta se puede recuperar en segundos usando _total_Seconds()

#Este for nos imprime en segundos cuanto tiempo hay de un microsegundo a 1 segundo de 1 segundo a 1 segundo de un 1 minuto a 1 segundo, etc...
for delta in [datetime.timedelta(microseconds=1),
              datetime.timedelta(seconds=1),
              datetime.timedelta(minutes=1),
              datetime.timedelta(hours=1)]:
    print('{:15} = {:8} seconds'.format(str(delta),delta.total_seconds())) #con {:15} realizamos un espaciado
print()

#Haciendo operaciones con fechas
hoy = datetime.date.today() 
two_day = datetime.timedelta(days=2)

#timedelta acepta enteros, flotantes, * , / 
anteayer = hoy - two_day
print('Anteayer: ', anteayer)
pasado_mañana = hoy + two_day
print('Pasado mañana: ', pasado_mañana)
print()

print('Hoy  :', datetime.datetime.now())
print('Ayer :', datetime.datetime.today())
print('UTC Ahora:   ', datetime.datetime.utcnow())

columnas = ['year',
            'month',
            'day',
            'hour',
            'minute',
            'second',
            'microsecond',]

hoy = datetime.datetime.now()
for attr in columnas:
    print('{:15}: {}'.format(attr, getattr(hoy, attr))) 

#con getattr() obtenemos una llamada de los atributos contenido en la clase datetime. 
#Y hoy como fecha para la devolución de los atributos de datetime('year', 'month')
#Recorreme columnas y devueleme los atributos de datetime.datetime.now(), por cada llamada a los atributos contenidos dentro columnas


