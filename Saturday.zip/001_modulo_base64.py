import base64, os

#BASE 16
cadena_bytes = b'Python es tremendo'
print(cadena_bytes)
print()

#Codificación base16
digitos_hex = base64.b16encode(cadena_bytes)
print(digitos_hex)
print()

#decoficación base16
#base64.b16decode(s, casefold=False)
'''casefold=False es opcional especifica sin alfabeto en minuscula 
es aceptable como entrada, vienepor defecto en false'''
cadena_bytes = base64.b16decode(digitos_hex)
print(cadena_bytes)
print()


#BASE32



#codificación base32:
cadena_bytes2 = b'Python es tremendo'
digitos_hex2 = base64.b32encode(cadena_bytes2)
print(digitos_hex2)
print()

#Decoodificación base32
#base64.b32decode(s, casefold=False, map01=none)
'''casefold opcional especifica si un alfabeto 
en minúsculas es aceptable como entrada por seguridad el 
valor predeterminado es false. permite la asignacion opcional
de 0 a la letra o y el 1 a la letra l. el argumento map01
no es NONE especifica a que letra debe asignar el 1
cuando map01 no es None el 0 siempre se asigna a la 
letra O, por seguridad es None por que le 0 y 1 no están permitidos como entrada'''

cadena_bytes2 = base64.b32decode(digitos_hex2)
print(cadena_bytes2)
print()


#BASE64



#base64.b64encode(s, altchars=None)
#altchars tiene como predeterminado None para utilizar el estándar base64
cadena_bytes3 = b'Python es tremendo'
digitos_hex3 = base64.b32encode(cadena_bytes3)
print(digitos_hex3)
print()

#decodificación:
#base64.b64decode(s, altchars=None, validate=False)'''
'''Esta función es la inversa de la anterior, es decir, acepta una cadena de bytes codificadad en base64 y nos devuelte el objeto binario inicial.
El segundo parámetro es identico al de b64encode, permite usar la codificacion alternativa para URLs y sistemas de ficheros.
Si la codificación tuviera el error de no estar bien alineada (es decir, que la longitud del texto no sea múltiplo de 4, como explicamos antes) 
la función eleva la excepción binascii.Error. Por ultimo, el tercer parámetro, validate, por defecto puesto a False, comprueba si los caracteres 
usados corresponden con la tabla de valores permitidos por base64. Con el valor False asignado por defecto, cualquiera de esos valores es simplemente 
descartado. Sin embargo, si se establece a True, la aparicion de cualquier caracter no permitido daría lugar a una excepción binascii.Error.
'''

cadena_bytes3 = base64.b32decode(digitos_hex3)
print(cadena_bytes3)
print()



# base64.standard_b64encode(s)
'''Utiliza la codificación original. Es equivalente a llamar a base64.b64encode especificando altchars=None, pero deja más patente la intención del programador.'''

# base64.standard_b64decode(s)
'''Igual que el anterior, pero para la decodificación. De igual manera usar este formula deja más clara la intención asi como el protocolo usado.'''

# base64.urlsafe_b64encode(s)
'''Utiliza la codificación safe for URL and filenames. Es equivalente a llamar a base64.b64encode especificando altchars="-_", pero deja más patente la intención del programador.'''

# base64.urlsafe_b64decode(s)
# base64.a85encode(b, *, foldspaces=False, wrapcol=0, pad=False, adobe=False)
# base64.a85decode(b, *, foldspaces=False, adobe=False, ignorechars=b' \t\n\r\v')
# base64.b85encode(b, pad=False)
# base64.b85decode(b)
# base64.decode(input, output)
# base64.decodebytes(s)
# base64.decodestring(s)
# base64.encode(input, output)
# base64.encodebytes(s)
# base64.encodestring(s)

'''Acceder a una imagen embebida dentro del documento sin necesidad de acceder a un recurso externo con la siguiente expresión
data:<tipo mime describiendo el formato>;<codificacion>, <datos>
'''
# Codificando gif en base64
with open('Clase/Librerias/base64/totoro.gif', 'rb') as img_file:
    image = base64.b64encode(img_file.read())

#Guardando variable con el contenido de la imagen codificada en un txt    
print(image)
with open('Clase/Librerias/base64/totoro2.txt', 'w', encoding=('utf-8')) as save_to_text:
    archivo = open('Clase/Librerias/base64/totoro.txt', 'wb')
    archivo.write(image)


#Decodificando un txt con datos en base64 que contiene una imagen
with open('Clase/Librerias/base64/totoro.txt', 'rb') as img_txt:
    img_txt = img_txt.read()
    img_txt_decode = base64.b64decode(img_txt)

# Con b le digo el tipo de dato requerido y con r o w si va a ser lectura o escritura dentro de open
with open('Clase/Librerias/base64/totoro2.gif', 'wb') as save_to_gif:
    
    save_to_gif.write(img_txt_decode)
    print(img_txt_decode)

#Generando nuevo archivo gif decodificado
with open('Clase/Librerias/base64/totoro2.txt', 'w', encoding=('utf-8')) as save_to_text:
    save_to_text.write(str(img_txt_decode))

    
'''Si da algún problema mirar el path, y ver donde estamos ubicados.'''








