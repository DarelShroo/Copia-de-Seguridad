import itertools
a = list(itertools.chain(range(5), range(5, 11)))
print(a)