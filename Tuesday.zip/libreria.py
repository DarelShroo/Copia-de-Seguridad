import zlib

message = "Hola, me llamo Íñigo Montoya. Tu mataste a mi padre. Preparate a morir".encode("utf-8")
print(f"El mensaje origina ocupa {len(message)} bytes")
compressed = zlib.compress(message)
print(f"El mensaje comprimido ocupa {len(compressed)} bytes")