import copy
import functools

#Con copy() y deepcopy() clonamos cualquier objeto

@functools.total_ordering
class MyClass:

    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return self.name == other.name

    def __gt__(self, other):
        return self.name > other.name


a = MyClass('a')
my_list = [a]
dup = copy.copy(my_list)

print('             my_list:', my_list)
#El primer elemento de la lista ya no es la misma referencia de objeto
#pero cuando se comparan los dos objetos, todavía se evalúan como iguales.
print('                 dup:', dup)
print('      dup is my_list:', (dup is my_list))
print('      dup == my_list:', (dup == my_list))
print('dup[0] is my_list[0]:', (dup[0] is my_list[0]))
print('dup[0] == my_list[0]:', (dup[0] == my_list[0]))

#Controlar como se hacen las copias
#__copy__( se llama sin ningún argumento) y debe devolver una copia superficial del objeto
#__deepcopy__() se llama con un diccionario memo y debe devolver una copia profunda del objeto.
#Cualquier atributo que necesite ser copiado profundamente debe ser pasado a copy.deepcopy()
#junto con el diccionario memo para controlar la recursión

