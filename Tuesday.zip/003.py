num = float(input('Escribe un numero '))
numero = int(input('Escribe un numero '))
if numero == 0:
    print('Error')
else:
    print(num/numero)
