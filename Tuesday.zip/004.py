edad = int(input('Introduce tu edad     \n'))
ingresos = int(input('Introduce tus ingresos    \n'))

if edad > 16:
    if ingresos >= 1000:
        print('tienes que tributar')
    else:
        print('No tienes que tributar')
else:
    print('No tienes que tributar')