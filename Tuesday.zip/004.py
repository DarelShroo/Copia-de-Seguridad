entero = int(input('Escribe un entero positivo'))
suma = print((entero+1) / 2)