import random

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
            print("Se llama al constructor de la clase Accumulator")
            cls._instances[cls].value = random.randrange(1000000)
        return cls._instances[cls]

class Accumulator(metaclass=Singleton):
    def __repr__(self):
        return f"Acumulator(value={self.value})"
    def inc(self):
        self.value += 1
        
acc1 = Accumulator()
print(acc1, id(acc1))
acc2 = Accumulator()
print(acc2, id(acc2))
acc2.inc()
assert acc1.value == acc2.value
assert acc1 is acc2