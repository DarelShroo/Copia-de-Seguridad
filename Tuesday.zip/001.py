user = input('Escribe tu nombre de usuario: ')

print(user.upper() + ' tiene ' + str(len(user)) + ' letras')