class PyGameImp:
    def init(self):
        print("La implementacion de PyGame se inicializa")
        
    def point(self, x, y):
        print(f"PyGame imprime un pixel en {x}, {y}")
        
    def line(self, x0, y0, x1, y1):
        print(f"PyGame dibuja una linea entre {x0}, {y0} y {x1}, {y1}")